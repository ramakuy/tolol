const help = (prefix) => { 
	return `                 
🔹BOT-XRYUU🔹
● *Status* : *Online*
● *Fitur* : *Banyak*
● *Error?* : *.report [Pertanyaan]*
● *Web Api* : *xptnbotapi.herokuapp.com*
● *Special Thanks To* :
●———  *XP-TN*  ———
●———— *Alfa* ————
╔▣━━━❨ STICKER ❩━━━▣┓
┃
┣➤ *${prefix}sticker*
┣➤ *${prefix}tsticker*
┃
┣▣━━━❨    MORE    ❩━━━▣┓
┃
┣➤ *${prefix}donasi*
┣➤ *${prefix}info*
┃
┣▣━━━°❀ ❬ KERANG MENU ❭ ❀°━━━▣┓
┃
┣➤ *${prefix}kapankah*
┣➤ *${prefix}bisakah*
┣➤ *${prefix}apakah*
┣➤ *${prefix}watak*
┣➤ *${prefix}hobby*
┣➤ *${prefix}rate*
┃
┣▣━━━❨   MARKER   ❩━━━▣┓
┃
┣➤ *${prefix}nulis* <teks>
┣➤ *${prefix}image* <teks>
┣➤ *${prefix}pronlogo*  <teks> | <teks>
┣➤ *${prefix}ttp* <teks>
┣➤ *${prefix}testing2* <teks>
┣➤ *${prefix}stiltext* <teks>
┣➤ *${prefix}galaxtext* <teks>
┣➤ *${prefix}thunder* <teks>
┣➤ *${prefix}wolflogo <teks> | <teks>*
┣➤ *${prefix}lionlogo <teks> | <teks>*
┣➤ *${prefix}textscreen <teks>*
┣➤ *${prefix}tahta <teks>*
┣➤ *${prefix}rtext <teks>*
┣➤ *${prefix}glitch <teks> | <teks>*
┣➤ *${prefix}party <teks>*
┣➤ *${prefix}lovemake <teks>*
┣➤ *${prefix}text3d <teks>*
┣➤ *${prefix}ninjalogo <teks> | <teks>*
┣➤ *${prefix}water* <teks>
┣➤ *${prefix}pinterest* <teks>
┃
┣▣━━━°❀ ❬ IMAGE❭ ❀°━━━▣┓
┃
┣➤ *${prefix}naruto*
┣➤ *${prefix}minato*
┣➤ *${prefix}boruto*
┣➤ *${prefix}hinata*
┣➤ *${prefix}sasuke*
┣➤ *${prefix}sakura*
┣➤ *${prefix}epep*
┣➤ *${prefix}walpaperhd*
┣➤ *${prefix}randomcat*
┃
┣▣━━━❨    NSFW    ❩━━━▣┓
┃
┣➤ *${prefix}randomhentai*
┣➤ *${prefix}nsfwtrap*
┣➤ *${prefix}nsfwloli*
┣➤ *${prefix}nsfwneko*
┣➤ *${prefix}nsfwblowjob*
┃
┃Jika Ingin mengaktifkan nya ketik
┃nsfw1 kalo mau di nonaktifkan nsfw0
┣▣━━━❨ ANIMALS ❩━━━▣┓
┃
┣➤ *${prefix}anjing*
┣➤ *${prefix}unta*
┣➤ *${prefix}babi*
┣➤ *${prefix}elang*
┣➤ *${prefix}inu*
┣➤ *${prefix}pokemon*
┃
┣▣━━━❨  DOWNLOAD  ❩━━━▣┓
┃
┣➤ *${prefix}ytsearch* [search yt]
┣➤ *${prefix}ytmp3* [link]
┣➤ *${prefix}ytmp4* [link]
┣➤ *${prefix}tiktok* [link]
┃
┣▣━━━❨  GROUP  ❩━━━▣┓
┃
┣➤ *${prefix}add* [62xxx]
┣➤ *${prefix}kick* [tag]
┣➤ *${prefix}setpp*
┣➤ *${prefix}setname*
┣➤ *${prefix}setdesc*
┣➤ *${prefix}unpromote* [tag]
┣➤ *${prefix}promote* [tag]
┣➤ *${prefix}tagall*
┣➤ *${prefix}group* [buka/tutup]
┣➤ *${prefix}welcome* [1/0]
┣➤ *${prefix}nsfw* [1/0]
┣➤ *${prefix}simih* [1/0]
┣➤ *${prefix}openanime* [1/0]
┣➤ *${prefix}listadmin*
┣➤ *${prefix}groupinfo*
┣➤ *${prefix}infogc*
┣➤ *${prefix}hidetag*
┣➤ *${prefix}tagme*
┣➤ *${prefix}delete*
┃
┣▣━━━❨    INFO    ❩━━━▣┓
┃
┣➤ *${prefix}infonomor*
┣➤ *${prefix}resepmakanan*
┣➤ *${prefix}infomotor*
┣➤ *${prefix}infomobil*
┣➤ *${prefix}blocklist*
┣➤ *${prefix}map*
┣➤ *${prefix}infogempa*
┣➤ *${prefix}infogithub*
┣➤ *${prefix}infocuaca*
┣➤ *${prefix}creator*
┃
┣▣━━━❨   OWNER   ❩━━━▣┓
┃
┣➤ *${prefix}bc* 
┣➤ *${prefix}leave*
┣➤ *${prefix}clearall*
┣➤ *${prefix}setprefix*
┣➤ *${prefix}clone* [tag]
┣➤ *${prefix}block*
┣➤ *${prefix}unblock*
┣➤ *${prefix}getses*
┃
┣▣━━━━❨    WIBU    ❩━━━━▣┓
┃
┣➤ *${prefix}nekonime*
┣➤ *${prefix}randomanime*
┣➤ *${prefix}wait*
┣➤ *${prefix}anime*
┣➤ *${prefix}loli*
┣➤ *${prefix}waifu*
┣➤*${prefix}wibu*
┣➤ *${prefix}waifu2*
┣➤ *${prefix}neko*
┃
┣▣━━━━❨   STALK   ❩━━━━▣┓
┃
┣➤ *${prefix}tiktokstalk*
┣➤ *${prefix}igstalk* 
┃
┣▣━━━❨   OTHER   ❩━━━▣┓
┃
┣➤ *${prefix}url2img*
┣➤ *${prefix}quotes*
┣➤ *${prefix}bucin*
┣➤ *${prefix}persengay*
┣➤ *${prefix}primbonjodoh <teks> | <teks>*
┣➤ *${prefix}artinama <nama>*
┣➤ *${prefix}ramalhp <nomor>*
┣➤ *${prefix}indohot*
┣➤ *${prefix}brainly*
┣➤ *${prefix}joox* <namalagu>
┣➤ *${prefix}hilih*
┣➤ *${prefix}meme*
┣➤ *${prefix}memeindo*
┣➤ *${prefix}lirik* <namalagu>
┣➤ *${prefix}ramaljadian*
┃
┣▣━━━❨   SOUND   ❩━━━▣┓
┃
┣➤ *${prefix}baka*
┣➤ *${prefix}Baka*
┣➤ *${prefix}arigato*
┃
┣━━━━━━━━━━━━━━━━━━━━
┃🔹BOT BY XRYUU🔹
╚━━━━━━━━━━━━━━━━━━━━`
}
exports.help = help